const axios = require('axios');
const cheerio = require('cheerio');

class Dmc {
    constructor() {
        this.url = "https://portal.bopp-obec.info";
        this.obecversion = "obec66";
        this.session = axios.create({
            withCredentials: true
        });
    }

    async Login(username, password) {
        const payload = `j_username=${username}&j_password=${password}&btnSubmit=%E0%B9%80%E0%B8%82%E0%B9%89%E0%B8%B2%E0%B8%AA%E0%B8%B9%E0%B9%88%E0%B8%A3%E0%B8%B0%E0%B8%9A%E0%B8%9A`;
        const headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'th,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://portal.bopp-obec.info',
            'Pragma': 'no-cache',
            'Referer': `${this.url}/${this.obecversion}/auth/login`,
            'User-Agent': 'Mozilla/5.0'
        };

        const response = await this.session.post(`${this.url}/${this.obecversion}/auth/j_spring_security_check`, payload, { headers });
        return response.headers['set-cookie'];
    }

    async CheckLogin(token) {
        const headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'th,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
            'Cache-Control': 'no-cache',
            'Cookie': `JSESSIONID=${token}`,
            'Pragma': 'no-cache',
            'User-Agent': 'Mozilla/5.0'
        };

        const response = await this.session.get(`${this.url}/${this.obecversion}/`, { headers });
        const $ = cheerio.load(response.data);
        const logoutLink = $(`a[href='/${this.obecversion}/auth/logout']`);
        return logoutLink.length > 0;
    }

    async GetstudentdtAll_Details(idstudentget, token) {
        const url = `${this.url}/${this.obecversion}/student/${idstudentget}`;
        const headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Cookie': `JSESSIONID=${token}`,
            'User-Agent': 'Mozilla/5.0'
        };

        const response = await this.session.get(url, { headers });
        if (response.status === 200) {
            const $ = cheerio.load(response.data);
            const tabgeneralinfo = $('input.input-xlarge');
            const dtAll = tabgeneralinfo.attr('id').split("TxStudent ")[1];

            const data = {};
            dtAll.match(/([a-zA-Z]+)=([^,]+)/g).forEach(pair => {
                const [key, value] = pair.split('=');
                data[key] = value;
            });

            $('select').each((i, el) => {
                const selectId = $(el).attr('name') || "";
                const selectedOption = $(el).find('option[selected]').text() || "";
                data[selectId] = selectedOption;
            });

            return [true, data];
        } else {
            return [false];
        }
    }

    async __Getstudent_data(params, token) {
        const headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Cookie': `JSESSIONID=${token}`,
            'User-Agent': 'Mozilla/5.0'
        };

        const response = await this.session.get(`${this.url}/${this.obecversion}/student/`, { params, headers });
        if (response.status === 200) {
            return {
                status: true,
                params: params,
                responsetxt: response.data,
                response: response
            };
        } else {
            return {
                status: false,
                params: params,
                responsetxt: response.data,
                response: response
            };
        }
    }

    async Getdetails(params, token) {
        let i = 0;
        let d = {};
        while (true) {
            i++;
            const response = await this.__Getstudent_data({ ...params, 'page.page': i }, token);
            if (response.status) {
                const $ = cheerio.load(response.responsetxt);
                $('table.table.table-bordered tr').each((index, row) => {
                    const rowData = $(row).find('td').map((i, el) => $(el).text().trim()).get();
                    if (rowData.length > 1) {
                        d[rowData[1]] = rowData;
                    }
                });

                const paginationDisabled = $('.pagination ul li.disabled').length > 0;
                if (paginationDisabled) break;
            } else {
                return [false];
            }
        }
        return [true, d];
    }
}

module.exports = Dmc;
