const express = require('express');
const app = express();
const Dmc = require('./DMC'); // Import the DMC module

// เริ่มต้นการทำงานกับ DMC
const Start = new Dmc();

// ตั้งค่าชื่อผู้ใช้และรหัสผ่าน
const username = '3940200404951';
const password = '94026634dmc';

app.get('/student', async (req, res) => {
    // รับพารามิเตอร์จาก URL
    const firstNameTh = req.query.firstNameTh;
    const lastNameTh = req.query.lastNameTh;

    // ตรวจสอบว่าพารามิเตอร์ครบหรือไม่
    if (!firstNameTh || !lastNameTh) {
        return res.status(400).json({ message: 'Missing required parameters' });
    }

    // ล็อกอินเข้าสู่ระบบ
    const loginResult = await Start.Login(username, password);
    if (!Start.CheckLogin(loginResult)) {
        return res.status(401).json({ message: 'Login failed' });
    }

    // ดึงข้อมูลนักเรียนโดยใช้ชื่อนามสกุล
    const getStudentDetails = await Start.Getdetails({ token: loginResult, firstNameTh, lastNameTh });

    if (!getStudentDetails[0]) {
        return res.status(404).json({ message: 'No student data found' });
    } else {
        const studentData = getStudentDetails[1];
        let formattedStudents = [];

        for (const key in studentData) {
            const dt1 = studentData[key];
            const dt2 = dt1[7]; // รหัสนักเรียนที่ได้จากข้อมูล
            const dt3 = dt1[2].replace(/\s/g, '').split('-')[0]; // ตัดคำและแยกรหัส

            // ดึงรายละเอียดทั้งหมดของนักเรียนตามรหัส
            const response = await Start.GetstudentdtAll_Details({ idstudentget: `${dt2}:${dt3}`, token: loginResult });

            if (!response[0]) {
                return res.status(404).json({ message: `No data found for student ${dt2}:${dt3}` });
            } else {
                const studentDetails = response[1];

                // สร้างโครงสร้าง JSON ตามรูปแบบที่กำหนด
                const formattedData = {
                    student: {
                        "รหัสนักเรียน": studentDetails.studentNo || '',
                        "ชื่อ": studentDetails.firstNameTh || '',
                        "นามสกุล": studentDetails.lastNameTh || '',
                        "คำนำหน้า": studentDetails.titleCode || '',
                        "วันเกิด": (studentDetails.birthDate || '').split('T')[0],
                        "เพศ": studentDetails.genderCode || '',
                        "ระดับชั้น": studentDetails.levelDtlCode || '',
                        "ห้องเรียน": studentDetails.classroom || '',
                        "ปีการศึกษา": studentDetails.educationYear || '',
                        "จังหวัดที่เกิด": studentDetails.birthProvinceCode || '',
                        "ที่อยู่": {
                            "บ้านเลขที่": studentDetails.homeNo || '',
                            "หมู่ที่": studentDetails.psMoo || '',
                            "ตำบล": studentDetails.psTumbolCode || '',
                            "อำเภอ": studentDetails.psAmphurCode || '',
                            "จังหวัด": studentDetails.psProvinceCode || '',
                            "รหัสไปรษณีย์": studentDetails.psPostalCode || ''
                        },
                        "เบอร์โทรศัพท์": studentDetails.telNo || '-',
                        "น้ำหนัก": studentDetails.weight || '0.0',
                        "ส่วนสูง": studentDetails.height || '0.0'
                    },
                    "ผู้ปกครอง": {
                        "บิดา": {
                            "ชื่อ": `${studentDetails.fatherFirstNameTh || ''} ${studentDetails.fatherLastNameTh || ''}`,
                            "เบอร์โทรศัพท์": studentDetails.fatherTelNo || '-',
                            "เงินเดือน": studentDetails.fatherSalary || '0.0'
                        },
                        "มารดา": {
                            "ชื่อ": `${studentDetails.motherFirstNameTh || ''} ${studentDetails.motherLastNameTh || ''}`,
                            "เบอร์โทรศัพท์": studentDetails.motherTelNo || '-',
                            "เงินเดือน": studentDetails.motherSalary || '0.0'
                        }
                    },
                    "ข้อมูลทั่วไป": {
                        "สถานะ": studentDetails.occasionCodes || 'ไม่มีข้อมูล',
                        "วันที่เข้าศึกษา": (studentDetails.admissionDate || '').split('T')[0],
                        "การพักนอนของนักเรียน": studentDetails.homelessCode || '',
                        "ความพิการ": studentDetails.deformityCode || '',
                        "การเดินทาง": studentDetails.journeyTypeCode || ''
                    }
                };
                formattedStudents.push(formattedData);
            }
        }
        return res.status(200).json(formattedStudents);
    }
});

app.listen(5000, () => {
    console.log('Server is running on port 5000');
});
